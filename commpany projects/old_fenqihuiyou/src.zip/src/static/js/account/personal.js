$(function(){
   $('#foot_check3').attr('src', '../../static/bitmap/foot/index_foot_check3.png');
   $('#foot_check3').siblings('span').css('color', 'red');
});
